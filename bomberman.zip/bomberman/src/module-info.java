/**
 * 
 */
/**
 * @author Makro
 *
 */
module bomberman {
}